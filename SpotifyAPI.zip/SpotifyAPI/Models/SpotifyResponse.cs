﻿using System.Collections.Generic;

namespace SpotifyAPI.Models
{
    public class SpotifyResponse
    {
        public List<Artist> Artists { get; set; } = new List<Artist>();

      
    }
}

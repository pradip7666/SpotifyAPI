﻿
namespace SpotifyAPI.Models
{
    public class ResponseDTO
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}

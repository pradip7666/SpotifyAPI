﻿namespace SpotifyAPI.Models
{
    public class SpotifyRequest
    {
        public string Genre { get; set; }
    }
}

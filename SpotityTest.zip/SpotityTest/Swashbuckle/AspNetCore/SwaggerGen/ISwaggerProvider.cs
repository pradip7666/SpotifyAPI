﻿namespace Swashbuckle.AspNetCore.SwaggerGen
{
    internal interface ISwaggerProvider
    {
    }
}